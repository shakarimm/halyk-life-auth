<template>
  <div class="wrapper">
    <router-view/>
  </div>
</template>